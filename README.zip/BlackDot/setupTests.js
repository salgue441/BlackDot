require("dotenv").config({ path: "./nodemon.json" })
