-- Modificar el órden de Retro y Reporte ( Reporte --> Retro)

INSERT INTO Cuantitativa
    (contenido, idPregunta, idRetroalimentacion)
VALUES
    (4, 1, 2),
    (3, 2, 4),
    (1, 3, 2);